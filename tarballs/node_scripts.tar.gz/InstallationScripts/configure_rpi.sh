#!/bin/bash

#############################################################################################################
# Functions
#############################################################################################################
function changeKeyboardToUS()
{
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Setting keyboard map to US..."
    sudo localectl set-x11-keymap us
}

function enableAutoLogin()
{
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Enabling auto-login..."
    if [ -f "/etc/systemd/system/getty@tty1.service.d/autologin.conf.orig" ]; then
        echo "     ==> autologin.conf file has already been created."
    else
        if [ -f "/etc/systemd/system/getty@tty1.service.d/autologin.conf" ]; then
            echo "     ==> Moving autologin.conf file to autologin.conf.orig"
            sudo mv /etc/systemd/system/getty@tty1.service.d/autologin.conf /etc/systemd/system/getty@tty1.service.d/autologin.conf.orig
        fi
        echo "     ==> Creating new autologin.conf file."
        if [ ! -d /etc/systemd/system/getty@tty1.service.d ]; then
            echo "     ==> getty@tty1.service.d directory does not exist; creating it (/etc/systemd/system/getty@tty1.service.d)"
            sudo mkdir -p /etc/systemd/system/getty@tty1.service.d
        fi
        sudo cp $HOME/Runtime/NodeFiles/OperSysSupportFiles/autologin.conf  /etc/systemd/system/getty@tty1.service.d/autologin.conf
        sudo chmod 644 /etc/systemd/system/getty@tty1.service.d/autologin.conf
        sudo chown root: /etc/systemd/system/getty@tty1.service.d/autologin.conf
    fi
    if [ -f "/etc/systemd/system/getty@tty1.service.d/noclear.conf" ]; then
        echo "     ==> noclear.conf already exists."
    else
        echo "     ==> Creating noclear.conf file."
        if [ ! -d /etc/systemd/system/getty@tty1.service.d ]; then
            echo "     ==> getty@tty1.service.d directory does not exist; creating it (/etc/systemd/system/getty@tty1.service.d)"
            sudo mkdir -p /etc/systemd/system/getty@tty1.service.d
        fi
        sudo cp $HOME/Runtime/NodeFiles/OperSysSupportFiles/noclear.conf  /etc/systemd/system/getty@tty1.service.d/noclear.conf
        sudo chmod 644 /etc/systemd/system/getty@tty1.service.d/noclear.conf
        sudo chown root: /etc/systemd/system/getty@tty1.service.d/noclear.conf
    fi
}

function updateUDevUSBRules()
{
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Updating USB Rules..."
    UDEV_RULES_FILE="/etc/udev/rules.d/99-usb-permissions.rules"
    
    # Check if the udev rules file already exists
    if [ -f "$UDEV_RULES_FILE" ]; then
        echo "     ==> The udev rule file $UDEV_RULES_FILE already exists."
        exit 0
    fi
    
    # Create the udev rule to set global permissions on USB devices
    echo 'SUBSYSTEM=="usb", MODE="0666"' | sudo tee $UDEV_RULES_FILE > /dev/null
    echo 'KERNEL=="tty*", MODE="0666"'  | sudo tee $UDEV_RULES_FILE > /dev/null

    # Ensure the permissions are correctly set on the rules file
    sudo chmod 644 $UDEV_RULES_FILE

    # Reload udev rules and trigger them
    echo "     ==> Reloading udev rules."
    sudo udevadm control --reload-rules
    sudo udevadm trigger
	
    # Confirmation message
    echo "     ==> USB device permissions have been set to 0666 for all users."
    echo "     ==> The rule has been written to $UDEV_RULES_FILE."
}

function modifybashrc()
{
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Modifying .bashrc..."
    grep -qxF '# Start UnReal Node Application' ~/.bashrc || echo -e "\n# Start UnReal Node Application\nif [[ \$(tty) == /dev/tty* ]]; then\n    /opt/node/UE5Node/start_node.sh\nfi\n" >> ~/.bashrc

    echo "    ==> start_node.sh successfully appended to ~/.bashrc."
}

function disableUnattendedUpgrades()
{
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Disabling unattended-upgrades..."
    # Disable unattended upgrades
    echo "     ==> Disabling unattended-upgrades service."
    sudo systemctl disable unattended-upgrades
    sudo systemctl stop unattended-upgrades

    # Lock all APT packages to prevent upgrades
    echo "     ==> Locking all APT packages to prevent upgrades."
    sudo apt-mark hold $(dpkg --get-selections | grep -v deinstall | awk '{print $1}')


    # Configure APT to stop periodic updates and downloads
    echo "     ==> Configuring APT to disable all automatic upgrades."
    sudo tee /etc/apt/apt.conf.d/99no-upgrades > /dev/null <<EOF
APT::Periodic::Update-Package-Lists "0";
APT::Periodic::Download-Upgradeable-Packages "0";
APT::Periodic::AutocleanInterval "0";
EOF

    # Remove any upgrade commands from crontab
    echo "     ==> Removing upgrade commands from system crontabs."
    sudo sed -i '/apt/d' /etc/crontab
    sudo sed -i '/upgrade/d' /etc/crontab
    # Remove user crontab entries if they contain upgrade commands
    (crontab -l | grep -v -e 'apt' -e 'upgrade') | crontab -

    # Restrict the apt command to prevent manual upgrades
    echo "     ==> Restricting permissions on the apt command to prevent manual upgrades."
    sudo chmod -x /usr/bin/apt

    echo "     ==> System is now configured to prevent any kind of upgrades."
}

function setupDSI()
{
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Configuring Waveshare display..."
    grep -qxF 'dtoverlay=vc4-kms-v3d' /boot/firmware/config.txt || echo 'dtoverlay=vc4-kms-v3d' | sudo tee -a /boot/firmware/config.txt
    grep -qxF 'dtoverlay=vc4-kms-dsi-waveshare-panel,10_1_inch' /boot/firmware/config.txt || echo 'dtoverlay=vc4-kms-dsi-waveshare-panel,10_1_inch' | sudo tee -a /boot/firmware/config.txt

    echo "     ==> Instructed the Raspberry Pi’s firmware to load a specific device tree overlay that configures how the hardware interacts with the Waveshare display."
}

#############################################################################################################
# Main execution
#############################################################################################################
changeKeyboardToUS
enableAutoLogin
updateUDevUSBRules
disableUnattendedUpgrades
setupDSI
modifybashrc

