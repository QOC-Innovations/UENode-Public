#!/bin/bash

#########################################################################################################################
# Create directory for the UnReal Node application
#########################################################################################################################
echo "UnReal Node application:"
echo "---> Removing existing UnReal Node installation..."
if [ -d /opt/node ]; then
    sudo rm -r /opt/node 
fi
echo "---> Creating directory structure..."
sudo mkdir -p /opt/node
sudo chown -R qoc: /opt/node

echo "---> Installing UnReal Node application..."
cp -r $HOME/Runtime/NodeFiles/UE5Node /opt/node/

# Create start_node.sh
if [ -f /opt/node/UE5Node/start_node.sh ]; then
    echo "---> Removing script that starts UnReal Node application..."
    rm /opt/node/UE5Node/start_node.sh
fi

echo "---> Creating script that starts UnReal Node application..."
cat << 'EOF' > /opt/node/UE5Node/start_node.sh
#!/bin/bash
export LD_LIBRARY_PATH=/opt/node/UE5Node/Binaries/LinuxArm64:/opt/node/Vulkan/lib/aarch64-linux-gnu:/usr/local/lib:$LD_LIBRARY_PATH
export VK_ICD_FILENAMES=/opt/node/Vulkan/share/icd.d/broadcom_icd.aarch64.json
export LIBGL_DRIVERS_PATH=/opt/node/Vulkan/lib/aarch64-linux-gnu/dri
export MESA_DRIRC_PATH=/opt/node/Vulkan/share/drirc.d
export EGL_LOG_LEVEL=debug
export UE_PROJECT_ROOT=/opt/node/UE5Node
export UE_PLUGIN_DIR=$UE_PROJECT_ROOT/Plugins
export UE_CONTENT_DIR=$UE_PROJECT_ROOT/Content

rgpiod &
cage $UE_PROJECT_ROOT/Binaries/LinuxArm64/UE5Node-LinuxArm64-Shipping UE5Node >ue_node.log 2>&1
EOF
chmod 700 /opt/node/UE5Node/start_node.sh

#########################################################################################################################
# Install GPIO files
#########################################################################################################################
echo "GPIO file installation:"
echo "---> Removing existing GPIO objects..."
sudo rm -r /usr/local/bin/* >/dev/null 2>&1
sudo rm -r /usr/local/lib/* >/dev/null 2>&1

echo "---> Installing GPIO objects..."
sudo cp -r  $HOME/Runtime/NodeFiles/GPIO/bin/* /usr/local/bin/
sudo cp $HOME/Runtime/NodeFiles/GPIO/lib/liblgpio.so.1 /usr/local/lib/
sudo cp $HOME/Runtime/NodeFiles/GPIO/lib/librgpio.so.1 /usr/local/lib/
cd /usr/local/lib
sudo rm liblgpio.so librgpio.so >/dev/null 2>&1
sudo ln -s liblgpio.so.1 liblgpio.so
sudo ln -s librgpio.so.1 librgpio.so 
cd $HOME/Runtime/

#########################################################################################################################
# Install Orbit files
#########################################################################################################################
echo "Orbit Objects:"
echo "---> Removing existing Orbit files..."
sudo rm /usr/lib/libOrbitLibrary.so* >/dev/null 2>&1
sudo rm /usr/lib/libftd2xx.so* >/dev/null 2>&1

echo "---> Installing Orbit files..."
sudo cp $HOME/Runtime/NodeFiles/Orbit/lib/libOrbitLibrary.so.* /usr/lib/
sudo cp $HOME/Runtime/NodeFiles/Orbit/lib/libftd2xx.so.* /usr/lib/
cd /usr/lib/
sudo rm libOrbitLibrary.so libftd2xx.so >/dev/null 2>&1
sudo ln -s libOrbitLibrary.so.1.7 libOrbitLibrary.so 
sudo ln -s libftd2xx.so.1.4.27 libftd2xx.so 
cd $HOME/Runtime/

#########################################################################################################################
# Install Vulkan files
#########################################################################################################################
echo "Vulkan file installation:"
echo "---> Removing existing Vulkan files..."
if [ -d /opt/node/Vulkan ]; then
    sudo rm -r /opt/node/Vulkan/ 
fi
echo "---> Creating directory structure..."
sudo mkdir /opt/node/Vulkan
sudo chown qoc: /opt/node/Vulkan

echo "---> Installing Vulkan files..."
cp -r $HOME/Runtime/NodeFiles/Vulkan/ /opt/node/ 

echo "---> Creating symbolic links..."
cd /opt/node/Vulkan/lib/aarch64-linux-gnu
sudo ln -s libGLESv2.so.2.0.0 libGLESv2.so.2
sudo ln -s libGLESv2.so.2 libGLESv2.so
sudo ln -s libEGL.so.1.0.0 libEGL.so.1
sudo ln -s libEGL.so.1 libEGL.so
sudo ln -s libgbm.so.1.0.0 libgbm.so.1
sudo ln -s libgbm.so.1 libgbm.so
sudo ln -s libGL.so.1.2.0 libGL.so.1
sudo ln -s libGL.so.1 libGL.so
sudo ln -s libglapi.so.0.0.0 libglapi.so.0 
sudo ln -s libglapi.so.0 libglapi.so
