#!/bin/bash

#############################################################################################################
# Functions
#############################################################################################################
function pythonPackageInstall()
{

    sudo pip3 install meson --break-system-packages
    sudo pip3 install mako --break-system-packages
    sudo pip3 install patool --break-system-packages
    sudo pip3 install GitPython --break-system-packages
    sudo pip3 install unrar --break-system-packages

}

function baseLinuxPackageInstall()
{
    sudo apt-get update -y
    sudo apt-get full-upgrade -y

    # System packages (these also include Dev packages for compilation)
    sudo apt-get install expect git python3 python3-dev python3-pip libxml2 -y
    sudo apt-get install xserver-xorg xinit x11-xserver-utils unattended-upgrades -y
    sudo apt-get install powermgmt-base fail2ban ufw rpi-chromium-mods cups unrar -y
    sudo apt-get install python3-setuptools unrar zip upzip unrar libglib2.0-dev -y
    sudo apt-get install cage unclutter udiskie xdg-user-dirs xwayland lightdm -y
    sudo apt-get install rpi-connect libusb-1.0-0-dev libcups2-dev -y
    sudo apt-get install build-essential make cmake  wget libnm-dev libcups2-dev -y
    sudo apt-get install libc6-dev libusb-1.0-0-dev libserialport-dev -y

    # Printer libraries
    sudo apt-get install printer-driver-all -y
    sudo apt-get install cups-filters -y
    sudo apt-get install printer-driver-cups-pdf -y
    sudo apt-get install hplip -y
    sudo apt-get install printer-driver-escpr -y
    sudo apt-get install printer-driver-brlaser -y
    sudo apt-get install printer-driver-splix -y
    sudo apt-get install printer-driver-gutenprint -y
    sudo apt-get install printer-driver-brlaser -y
#    sudo apt-get install printer-driver-zebra -y
}

#############################################################################################################
# Main execution
#############################################################################################################
baseLinuxPackageInstall
pythonPackageInstall

