#!/bin/bash

mv tarball/* ../
sudo rm configure_rpi.sh >/dev/null 2>&1
sudo rm install_*.sh* >/dev/null 2>&1
sudo rm -r NodeFiles >/dev/null 2>&1
sudo rm -r tarball >/dev/null 2>&1
