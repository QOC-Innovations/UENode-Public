#!/bin/bash

function disableUnattendedUpgrades()
{
    # Disable unattended upgrades
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Disabling unattended-upgrades service..."
    sudo systemctl disable unattended-upgrades
    sudo systemctl stop unattended-upgrades
    
    # Lock all APT packages to prevent upgrades
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Locking all APT packages to prevent upgrades..." 
    sudo apt-mark hold $(dpkg --get-selections | grep -v deinstall | awk '{print $1}')

    
    # Configure APT to stop periodic updates and downloads
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Configuring APT to disable all automatic upgrades..." 
    sudo tee /etc/apt/apt.conf.d/99no-upgrades > /dev/null <<EOF
APT::Periodic::Update-Package-Lists "0";
APT::Periodic::Download-Upgradeable-Packages "0";
APT::Periodic::AutocleanInterval "0";
EOF
    
    # Remove any upgrade commands from crontab
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Removing upgrade commands from system crontabs..."
    sudo sed -i '/apt/d' /etc/crontab
    sudo sed -i '/upgrade/d' /etc/crontab
    # Remove user crontab entries if they contain upgrade commands
    (crontab -l | grep -v -e 'apt' -e 'upgrade') | crontab -
    
    # Restrict the apt command to prevent manual upgrades
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Restricting permissions on the apt command to prevent manual upgrades..."
    sudo chmod -x /usr/bin/apt
    
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> System is now configured to prevent any kind of upgrades."
}

#####################################################################################################################
# Execution of bash script
#####################################################################################################################
disableUnattendedUpgrades
