#!/bin/bash

function performScheduledUpgrade()
{
    # Step 1: Remove hold on all packages to allow upgrades
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Re-enabling upgrades for all packages..."
    sudo apt-mark unhold $(dpkg --get-selections | grep -v deinstall | awk '{print $1}')

    # Step 2: Perform a full system upgrade
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Updating package lists and upgrading the OS..."
    sudo apt-get update && sudo apt-get full-upgrade -y

    # Step 3: Lock all packages again to prevent upgrades
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Locking all APT packages to prevent future upgrades..."
    sudo apt-mark hold $(dpkg --get-selections | grep -v deinstall | awk '{print $1}')

    # Step 4: Disable unattended upgrades service
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Disabling unattended-upgrades service..."
    sudo systemctl disable unattended-upgrades
    sudo systemctl stop unattended-upgrades

    # Step 5: Configure APT to stop periodic updates and downloads
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Configuring APT to disable all automatic upgrades..."
    sudo tee /etc/apt/apt.conf.d/99no-upgrades > /dev/null <<EOF
APT::Periodic::Update-Package-Lists "0";
APT::Periodic::Download-Upgradeable-Packages "0";
APT::Periodic::AutocleanInterval "0";
EOF

    # Step 6: Restrict permissions on the apt command to prevent manual upgrades
    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> Restricting permissions on the apt command to prevent manual upgrades..."
    sudo chmod -x /usr/bin/apt

    echo "$(date '+%Y-%m-%d %H:%M:%S') ==> System upgrade completed and locked down to prevent further upgrades."
}

function rebuildMesaVulkanBroadcomDrivers
{
    # Still need to do this
}

#####################################################################################################################
# Execution of bash script
#####################################################################################################################
performScheduledUpgrade
#rebuildMesaVulkanBroadcomDrivers   <===== TO DO!!!!!!!!!

